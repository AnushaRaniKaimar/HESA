﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bees
{
    class Program
    {
        static void Main(string[] args)
        {
            Bee wrk1 = new Worker();
            List<Worker> workers = new List<Worker>();
            int damageValue = 10;
            for (int i = 0; i < 10; i++)
            {
                workers.Add((Worker)wrk1);                
                workers[i].Damage(damageValue);
                damageValue += 10;
            }

            Bee qun = new Queen();
            List<Queen> queens = new List<Queen>();
            damageValue = 10;
            for (int i = 0; i < 10; i++)
            {
                queens.Add((Queen)qun);
                queens[i].Damage(damageValue);
                damageValue += 10;
            }

            Drone drn = new Drone();
            List<Drone> drones = new List<Drone>();
            damageValue = 10;
            for (int i = 0; i < 10; i++)
            {
                drones.Add((Drone)drn);
                drones[i].Damage(damageValue);
                damageValue += 10;
            }
        }
    }
}
