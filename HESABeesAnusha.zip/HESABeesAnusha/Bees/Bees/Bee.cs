﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bees
{
    public abstract class Bee
    {
        protected  static int health { get; set; }
        public Bee()
        {
            health = 100;
        }

        public abstract string Damage(int healthPercentage);

    }

}
