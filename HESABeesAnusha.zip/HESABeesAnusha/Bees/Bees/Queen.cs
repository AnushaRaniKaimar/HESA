﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bees
{
    public class Queen:Bee
    {
        public string IsAliveDead { get; set; }
        public Queen()
        {
            IsAliveDead = "Alive";
        }
        public override string Damage(int healthPercentage)
        {
            if (IsAliveDead == "Alive")
            {
                if ((health - healthPercentage) < 20)
                {
                    IsAliveDead = "Dead";
                }
            }
            Console.WriteLine("Current Health status of Queen Bee: " + (health - healthPercentage) + "% " + "Queen Bee Status: " + IsAliveDead);
            return IsAliveDead;
        }
    }
}
