﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bees
{
    public class Drone:Bee
    {
        public string IsAliveDead { get; set; }
        public Drone()
        {
            IsAliveDead = "Alive";
        }

        public override string Damage(int healthPercentage)
        {
            if (IsAliveDead == "Alive")
            {
                if ((health - healthPercentage) < 50)
                {
                    IsAliveDead = "Dead";
                }
            }
            Console.WriteLine("Current Health status of Drone Bee: " + (health - healthPercentage) + "% " + "Drone Bee Status: " + IsAliveDead);
            return IsAliveDead;
        }
    }
}
