﻿Output is written to console.

Improve the Solution:
Random value can be User fed, required field and a condition to fall between 0 to 10. 

Understanding:
Bee is an abstract class where health is a property with protected access modifier  -
because it needs to be read in child class

Damage is abstract method defined in child classes Queen, Drone and worker which holds 
the logic of reducing the percentage of health and dead property display


