﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bees
{
    public class Worker : Bee
    {
        public static string IsAliveDead { get; set; }
        public Worker():base()
        {
            IsAliveDead = "Alive";
        }
        public override string Damage(int healthPercentage)
        {
            if (IsAliveDead == "Alive")
            {
                if ((health - healthPercentage) < 70)
                {
                    IsAliveDead = "Dead";
                }                
            }
            Console.WriteLine("Current Health status of Worker Bee: "+ (health - healthPercentage) +"% "+"Worker Bee Status: " +IsAliveDead);
            return IsAliveDead;
        }

    }
}
